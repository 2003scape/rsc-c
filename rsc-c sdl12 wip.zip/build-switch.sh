source /etc/profile.d/devkit-env.sh

make -f Makefile.nx clean && make -f Makefile.nx